package com.sdut.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sdut.pojo.Student;

@Controller
public class StudentController {

	@RequestMapping("student")
	public String student(Student stu, Model model) {
		System.out.println(stu);

		if (stu.getAge() != null || stu.getId() != null || stu.getName() != null && stu.getName() != "") {
			model.addAttribute("stu", stu);
			return "studentInfo";

		} else {
			// 模拟查询商品列表
			return "success";

		}
	}
}
