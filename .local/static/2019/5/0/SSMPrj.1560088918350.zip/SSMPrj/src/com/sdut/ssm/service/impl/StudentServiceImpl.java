package com.sdut.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sdut.ssm.mapper.StudentMapper;
import com.sdut.ssm.pojo.Student;
import com.sdut.ssm.service.StudentService;


@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentMapper mapper;

	@Override
	public List<Student> getAllStudents() {
		return mapper.getAllStudents();
	
	}

	@Override
	public List<Student> getStudentsByVo(Student stu) {
		 return mapper.getStudentsByVo(stu);
	}
	@Override
	public int deleteStudentById(Integer id ) {

		return mapper.deleteStudentById(id);
		
	}

	@Override
	public int updateByStudent(Student stu) {
		 return mapper.updateByStudent(stu);
		 
	}

	@Override
	public int insertStudent(Student stu) {
		 return mapper.insertStudent(stu);
	}

	@Override
	public Student getStudentById(Integer id) {
		 return mapper.getStudentById(id);
		 
	}
	
	 
	
	
	
	

}
