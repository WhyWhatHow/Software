package com.sdut.mapper;

import java.util.List;

import com.sdut.pojo.Student;

public interface StudentMapper {
//	增加学生、删除学生、修改学生、查询所有学生、根据ID查询一名学生。
	public  Student selectById(int id );	
	public List<Student> selectAll();
	public int deleteById(int id );
	public int updateByStudent(Student stu) ; 
	public int insert(Student student );
}
