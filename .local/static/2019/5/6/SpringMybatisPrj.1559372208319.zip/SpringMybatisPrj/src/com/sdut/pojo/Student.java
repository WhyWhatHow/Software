package com.sdut.pojo;

import java.util.List;

public class Student {

	private Integer id;
	private String name;
	private Integer age;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student [sid=" + id + ", sname=" + name + ", sage=" + age + "]";
	}

	public Integer getSid() {
		return id;
	}

	public void setSid(Integer sid) {
		this.id = sid;
	}

	public String getSname() {
		return name;
	}

	public void setSname(String sname) {
		this.name = sname;
	}

	public Integer getSage() {
		return age;
	}

	public void setSage(Integer sage) {
		this.age = sage;
	}


	public Student(Integer sid, String sname, Integer sage) {
		super();
		this.id = sid;
		this.name = sname;
		this.age = sage;
	}

	public Student() {
		super();
	}

}
