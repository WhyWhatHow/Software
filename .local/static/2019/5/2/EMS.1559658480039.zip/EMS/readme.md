### 说明:

- 源程序 ：      EmpoyeeManagementSystem.mdj

- 图文件（svg格式）：       diagrams文件夹 下

- 项目整合文件：  uml_王京龙－邢鹏飞－企业员工管理系统.doc







　
